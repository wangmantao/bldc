/*	LARGE STACK MODEL <64K FOR STM8 COMPILER
 *	Copyright (c) 2006 by COSMIC Software
 */
#pragma space () @near
#pragma space * () @near
#pragma space const []

#define __MODSL0__	1
